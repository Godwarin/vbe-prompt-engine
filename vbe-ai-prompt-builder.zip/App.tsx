
import React, { useState } from 'react';
import { CATEGORIES, DEFAULT_PROMPT_STATE, UI_TEXT } from './constants';
import { PromptState, Lang } from './types';
import Section from './components/Section';
import { Copy, Terminal, Flame, Zap, Globe } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Lang>('ru'); // Default to Russian
  const [state, setState] = useState<PromptState>(DEFAULT_PROMPT_STATE);
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [copied, setCopied] = useState(false);

  const toggleLang = () => {
    setLang(prev => prev === 'en' ? 'ru' : 'en');
  };

  const buildPrompt = () => {
    const parts = [
      state.view ? `VIEW: ${state.view}` : '',
      state.colors ? `COLORS: ${state.colors}` : '',
      state.composition.length ? `COMPOSITION: ${state.composition.join(', ')}` : '',
      state.light.length ? `LIGHT: ${state.light.join(', ')}` : '',
      state.textures.length ? `TEXTURES: ${state.textures.join(', ')}` : '',
      state.art.length ? `STYLE: ${state.art.join(', ')}` : '',
      state.extras.length ? `EFFECTS: ${state.extras.join(', ')}` : '',
      state.size ? `SIZE: ${state.size}` : '',
    ].filter(Boolean);

    const watermark = "# Watermark: created by VBE — https://t.me/VBEvlog";
    const final = `Create an image.\n\n${parts.join('\n')}\n\n${watermark}`;
    setGeneratedPrompt(final);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const updateState = (key: keyof PromptState, value: any) => {
    setState(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen p-4 md:p-8 font-sans selection:bg-vbe-red selection:text-white">
      <div className="max-w-5xl mx-auto space-y-8">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-vbe-border pb-6 gap-4">
          <div>
            <h1 className="text-3xl md:text-5xl font-black italic tracking-tighter text-white flex items-center gap-3">
              <Flame className="text-vbe-red w-8 h-8 md:w-12 md:h-12 animate-pulse-slow" />
              VBE <span className="text-vbe-red">AI</span> PROMPT
              <span className="text-sm md:text-lg not-italic font-mono font-normal text-vbe-muted self-end mb-1 opacity-50">v3.0</span>
            </h1>
            <p className="text-vbe-muted font-mono text-xs md:text-sm mt-2 ml-1 uppercase">
              {UI_TEXT.subtitle[lang]}
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <button 
              onClick={toggleLang}
              className="flex items-center gap-2 px-3 py-1 bg-vbe-panel border border-vbe-border hover:border-vbe-red rounded text-xs text-vbe-text hover:text-white transition-all font-mono"
            >
              <Globe className="w-3 h-3" />
              <span className={lang === 'en' ? 'text-white font-bold' : 'text-vbe-muted'}>EN</span>
              <span className="text-vbe-border">|</span>
              <span className={lang === 'ru' ? 'text-white font-bold' : 'text-vbe-muted'}>RU</span>
            </button>
            <div className="px-3 py-1 bg-vbe-red/10 border border-vbe-red/30 rounded text-xs text-vbe-red font-mono animate-pulse">
              {UI_TEXT.systemOnline[lang]}
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Controls */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* View Input Section */}
            <div className="bg-vbe-panel p-5 rounded-lg border border-vbe-border">
              <div className="flex justify-between items-center mb-3">
                <label className="text-sm font-bold text-vbe-muted uppercase tracking-wider">
                  <Terminal className="inline w-4 h-4 mr-2" />
                  {UI_TEXT.sceneLabel[lang]}
                </label>
              </div>
              <textarea
                value={state.view}
                onChange={(e) => updateState('view', e.target.value)}
                placeholder={UI_TEXT.scenePlaceholder[lang]}
                className="w-full h-32 bg-black/50 border border-vbe-border rounded p-4 text-white placeholder-vbe-border focus:border-vbe-red focus:outline-none focus:ring-1 focus:ring-vbe-red transition-all font-mono text-sm"
              />
            </div>

            {/* Colors Input Section */}
            <div className="bg-vbe-panel p-5 rounded-lg border border-vbe-border">
              <label className="text-sm font-bold text-vbe-muted uppercase tracking-wider block mb-3">
                <Zap className="inline w-4 h-4 mr-2" />
                {UI_TEXT.colorLabel[lang]}
              </label>
              <input 
                type="text" 
                value={state.colors}
                onChange={(e) => updateState('colors', e.target.value)}
                placeholder={UI_TEXT.colorPlaceholder[lang]}
                className="w-full bg-black/50 border border-vbe-border rounded p-3 text-white placeholder-vbe-border focus:border-vbe-red focus:outline-none font-mono text-sm"
              />
            </div>

            {/* Dynamic Categories */}
            <div className="space-y-4">
              {CATEGORIES.map(cat => (
                <Section 
                  key={cat.id} 
                  category={cat} 
                  selectedValues={state[cat.id as keyof PromptState]}
                  onChange={(val) => updateState(cat.id as keyof PromptState, val)}
                  lang={lang}
                />
              ))}
            </div>

            {/* Build Button */}
            <button 
              onClick={buildPrompt}
              className="w-full py-4 bg-vbe-red hover:bg-vbe-redhover text-white font-black text-xl tracking-widest uppercase rounded shadow-[0_0_20px_rgba(255,0,0,0.4)] hover:shadow-[0_0_40px_rgba(255,0,0,0.6)] transition-all transform hover:-translate-y-1 active:translate-y-0"
            >
              {UI_TEXT.generateBtn[lang]}
            </button>
          </div>

          {/* Sticky Sidebar Results */}
          <div className="lg:col-span-4">
            <div className="sticky top-8 space-y-4">
              <div className="bg-vbe-panel border border-vbe-border rounded-lg p-1 overflow-hidden">
                <div className="bg-black/80 p-3 border-b border-vbe-border flex justify-between items-center">
                  <span className="text-xs font-mono text-vbe-muted">{UI_TEXT.consoleTitle[lang]}</span>
                  {generatedPrompt && (
                    <button 
                      onClick={copyToClipboard}
                      className="text-xs flex items-center gap-1 text-vbe-text hover:text-white transition-colors"
                    >
                      {copied ? <CheckIcon/> : <Copy className="w-3 h-3" />}
                      {copied ? UI_TEXT.copied[lang] : UI_TEXT.copy[lang]}
                    </button>
                  )}
                </div>
                <textarea 
                  readOnly
                  value={generatedPrompt}
                  placeholder="_"
                  className="w-full h-[60vh] bg-black p-4 text-xs md:text-sm font-mono text-vbe-text resize-none focus:outline-none leading-relaxed"
                />
              </div>
              
              <div className="p-4 rounded border border-vbe-border bg-vbe-panel/50 text-xs text-vbe-muted font-mono">
                <p>{UI_TEXT.statusReady[lang]}</p>
                <p>{UI_TEXT.userAnon[lang]}</p>
                <p>CONNECTION: SECURE</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CheckIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500"><polyline points="20 6 9 17 4 12"></polyline></svg>
  )
}
