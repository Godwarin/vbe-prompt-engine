
export type Lang = 'en' | 'ru';

export interface LocalizedString {
  en: string;
  ru: string;
}

export interface OptionItem {
  id: string;
  label: LocalizedString; // Changed to support dual language
  value: string; // The actual prompt text (always English)
}

export interface Category {
  id: string;
  title: LocalizedString; // Changed to support dual language
  icon?: string;
  type: 'single' | 'multi' | 'input';
  options?: OptionItem[];
  placeholder?: LocalizedString;
}

export interface PromptState {
  view: string;
  colors: string;
  size: string;
  composition: string[];
  light: string[];
  textures: string[];
  art: string[];
  digital: string[];
  extras: string[];
}
