
import React from 'react';
import { Category, Lang } from '../types';

interface SectionProps {
  category: Category;
  selectedValues: string[] | string;
  onChange: (value: string | string[]) => void;
  lang: Lang;
}

const Section: React.FC<SectionProps> = ({ category, selectedValues, onChange, lang }) => {
  const isMulti = category.type === 'multi';

  const handleToggle = (value: string) => {
    if (isMulti) {
      const current = Array.isArray(selectedValues) ? selectedValues : [];
      if (current.includes(value)) {
        onChange(current.filter(v => v !== value));
      } else {
        onChange([...current, value]);
      }
    } else {
      onChange(value);
    }
  };

  return (
    <div className="mb-6 p-5 bg-vbe-panel border border-vbe-border rounded-lg shadow-sm hover:border-vbe-red/40 transition-all duration-300 group">
      <h3 className="text-sm font-bold mb-4 text-vbe-muted flex items-center gap-2 uppercase tracking-[0.2em] group-hover:text-vbe-red transition-colors">
        <span className="w-2 h-2 bg-vbe-red rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></span>
        {category.title[lang]}
      </h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {category.options?.map((opt) => {
          const isSelected = isMulti 
            ? (selectedValues as string[]).includes(opt.value)
            : selectedValues === opt.value;

          return (
            <button
              key={opt.id}
              onClick={() => handleToggle(opt.value)}
              className={`
                relative flex items-center justify-start gap-2 p-3 text-xs md:text-sm font-medium rounded border transition-all duration-200
                ${isSelected 
                  ? 'bg-vbe-red text-white border-vbe-red shadow-[0_0_15px_rgba(255,0,0,0.3)]' 
                  : 'bg-black/40 text-vbe-text border-vbe-border hover:border-vbe-muted hover:bg-white/5'}
              `}
            >
              <div className={`w-3 h-3 rounded-full border flex items-center justify-center ${isSelected ? 'border-white' : 'border-vbe-muted'}`}>
                {isSelected && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
              </div>
              <span className="text-left leading-tight font-mono">{opt.label[lang]}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default Section;
