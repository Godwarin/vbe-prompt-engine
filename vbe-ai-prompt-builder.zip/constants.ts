
import { Category, LocalizedString } from './types';

export const DEFAULT_PROMPT_STATE = {
  view: '',
  colors: '',
  size: '1000x1000',
  composition: [],
  light: [],
  textures: [],
  art: [],
  digital: [],
  extras: []
};

export const UI_TEXT: Record<string, LocalizedString> = {
  subtitle: { en: '/// PROFESSIONAL GRADE PROMPT ENGINEERING SYSTEM', ru: '/// ПРОФЕССИОНАЛЬНАЯ СИСТЕМА СОЗДАНИЯ ПРОМТОВ' },
  systemOnline: { en: 'SYSTEM: ONLINE', ru: 'СИСТЕМА: АКТИВНА' },
  sceneLabel: { en: 'Scene Description (View)', ru: 'Описание сцены (View)' },
  scenePlaceholder: { en: "Describe your scene here (e.g., 'A cyberpunk samurai in neon rain')...", ru: "Опиши сцену здесь (например, 'Киберпанк самурай под неоновым дождем')..." },
  colorLabel: { en: 'Color Palette', ru: 'Цветовая палитра' },
  colorPlaceholder: { en: 'e.g. Red and Black, Neon Blue...', ru: 'например: Красный и черный, Неоновый синий...' },
  generateBtn: { en: 'Generate Prompt ///', ru: 'Сгенерировать Промт ///' },
  consoleTitle: { en: 'OUTPUT CONSOLE', ru: 'КОНСОЛЬ ВЫВОДА' },
  copy: { en: 'COPY', ru: 'КОПИРОВАТЬ' },
  copied: { en: 'COPIED', ru: 'СКОПИРОВАНО' },
  statusReady: { en: 'STATUS: VBE_PROMPT_BUILDER_V3.0_READY', ru: 'СТАТУС: VBE_PROMPT_BUILDER_V3.0_ГОТОВ' },
  userAnon: { en: 'USER: ANONYMOUS', ru: 'ПОЛЬЗОВАТЕЛЬ: АНОНИМ' },
};

export const CATEGORIES: Category[] = [
  {
    id: 'size',
    title: { en: 'SIZE / FORMAT', ru: 'РАЗМЕР / ФОРМАТ' },
    type: 'single',
    options: [
      { id: 'sq', label: { en: '1000x1000 (Square)', ru: '1000x1000 (Квадрат)' }, value: '1000x1000' },
      { id: 'p1', label: { en: '1080x1920 (Story)', ru: '1080x1920 (Сториз)' }, value: '1080x1920' },
      { id: 'l1', label: { en: '1920x1080 (HD)', ru: '1920x1080 (HD)' }, value: '1920x1080' },
      { id: 'mj1', label: { en: '--ar 16:9 (Midjourney)', ru: '--ar 16:9 (Горизонт)' }, value: '--ar 16:9' },
      { id: 'mj2', label: { en: '--ar 9:16 (Midjourney)', ru: '--ar 9:16 (Вертикаль)' }, value: '--ar 9:16' },
      { id: 'mj3', label: { en: '--ar 21:9 (Cinema)', ru: '--ar 21:9 (Кино)' }, value: '--ar 21:9' },
    ]
  },
  {
    id: 'composition',
    title: { en: 'COMPOSITION', ru: 'КОМПОЗИЦИЯ' },
    type: 'multi',
    options: [
      { id: 'c1', label: { en: 'Close-Up', ru: 'Крупный план' }, value: 'extreme close-up' },
      { id: 'c2', label: { en: 'Medium Shot', ru: 'Средний план' }, value: 'medium shot' },
      { id: 'c3', label: { en: 'Wide Angle', ru: 'Широкий угол' }, value: 'wide angle lens' },
      { id: 'c4', label: { en: 'Top-Down', ru: 'Вид сверху' }, value: 'top-down view' },
      { id: 'c5', label: { en: 'Symmetry', ru: 'Симметрия' }, value: 'symmetrical composition' },
      { id: 'c6', label: { en: 'Dynamic', ru: 'Динамика' }, value: 'dynamic action shot' },
      { id: 'c7', label: { en: 'Rule of Thirds', ru: 'Правило третей' }, value: 'rule of thirds' },
      { id: 'c8', label: { en: 'Low Angle', ru: 'Нижний ракурс' }, value: 'low angle shot' },
    ]
  },
  {
    id: 'light',
    title: { en: 'LIGHTING', ru: 'ОСВЕЩЕНИЕ' },
    type: 'multi',
    options: [
      { id: 'l1', label: { en: 'Cinematic', ru: 'Кинематографичное' }, value: 'cinematic lighting' },
      { id: 'l2', label: { en: 'Neon / Cyber', ru: 'Неон / Кибер' }, value: 'neon lighting, cyberpunk atmosphere' },
      { id: 'l3', label: { en: 'Volumetric', ru: 'Объемный свет' }, value: 'volumetric lighting, god rays' },
      { id: 'l4', label: { en: 'Rembrandt', ru: 'Рембрандт' }, value: 'Rembrandt lighting' },
      { id: 'l5', label: { en: 'Soft Diffused', ru: 'Мягкий рассеянный' }, value: 'soft diffused light' },
      { id: 'l6', label: { en: 'Studio', ru: 'Студийный' }, value: 'studio lighting' },
      { id: 'l7', label: { en: 'Dark / Moody', ru: 'Мрачный / Темный' }, value: 'dark gloomy atmosphere' },
      { id: 'l8', label: { en: 'Golden Hour', ru: 'Золотой час' }, value: 'golden hour' },
    ]
  },
  {
    id: 'textures',
    title: { en: 'TEXTURES & RENDER', ru: 'ТЕКСТУРЫ И РЕНДЕР' },
    type: 'multi',
    options: [
      { id: 't1', label: { en: '8K Ultra', ru: '8K Ультра' }, value: '8k resolution, ultra detailed' },
      { id: 't2', label: { en: 'Photorealism', ru: 'Фотореализм' }, value: 'hyperrealistic, photorealistic' },
      { id: 't3', label: { en: 'Unreal Engine 5', ru: 'Unreal Engine 5' }, value: 'Unreal Engine 5 render' },
      { id: 't4', label: { en: 'Octane Render', ru: 'Octane Render' }, value: 'Octane Render' },
      { id: 't5', label: { en: 'Ray Tracing', ru: 'Трассировка лучей' }, value: 'Ray Tracing, Global Illumination' },
      { id: 't6', label: { en: 'Matte', ru: 'Матовый' }, value: 'matte finish' },
      { id: 't7', label: { en: 'Glossy', ru: 'Глянцевый' }, value: 'glossy surfaces' },
    ]
  },
  {
    id: 'art',
    title: { en: 'ART STYLE', ru: 'ХУДОЖЕСТВЕННЫЙ СТИЛЬ' },
    type: 'multi',
    options: [
      { id: 'a1', label: { en: 'Realism', ru: 'Реализм' }, value: 'Realism' },
      { id: 'a2', label: { en: 'Cyberpunk', ru: 'Киберпанк' }, value: 'Cyberpunk style' },
      { id: 'a3', label: { en: 'Surrealism', ru: 'Сюрреализм' }, value: 'Surrealism' },
      { id: 'a4', label: { en: 'Anime (90s)', ru: 'Аниме (90-е)' }, value: '90s anime style' },
      { id: 'a5', label: { en: 'Concept Art', ru: 'Концепт-арт' }, value: 'digital concept art' },
      { id: 'a6', label: { en: 'Vaporwave', ru: 'Вейпорвейв' }, value: 'Vaporwave aesthetic' },
      { id: 'a7', label: { en: 'Analog Horror', ru: 'Аналоговый хоррор' }, value: 'VHS analog horror' },
      { id: 'a8', label: { en: 'Noir', ru: 'Нуар' }, value: 'Film Noir' },
    ]
  },
  {
    id: 'extras',
    title: { en: 'EFFECTS (FX)', ru: 'ЭФФЕКТЫ (FX)' },
    type: 'multi',
    options: [
      { id: 'e1', label: { en: 'Film Grain', ru: 'Зернистость' }, value: 'film grain' },
      { id: 'e2', label: { en: 'Chromatic Aberration', ru: 'Хроматика' }, value: 'chromatic aberration' },
      { id: 'e3', label: { en: 'Particles', ru: 'Частицы / Пыль' }, value: 'floating dust particles' },
      { id: 'e4', label: { en: 'Motion Blur', ru: 'Размытие движения' }, value: 'motion blur' },
      { id: 'e5', label: { en: 'Glitch', ru: 'Глитч' }, value: 'glitch effect' },
      { id: 'e6', label: { en: 'Vignette', ru: 'Виньетка' }, value: 'vignette' },
      { id: 'e7', label: { en: 'Bokeh', ru: 'Боке' }, value: 'bokeh' },
    ]
  }
];